create index mapit_postcode_areas_area_id_idx on mapit_postcode_areas (area_id);
