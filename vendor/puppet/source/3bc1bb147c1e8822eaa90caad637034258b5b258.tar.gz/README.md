# Puppet reporter for Sentry

This Puppet module sends reports about failed runs to <https://sentry.io/>.

You'll need the `sentry-raven` gem installed on the Puppet master.
