require 'spec_helper'

describe 'curl', :type => :class do

  it { is_expected.to compile }

  it { is_expected.to compile.with_all_deps }
end
