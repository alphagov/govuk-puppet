# puppet-harden

Harden an Ubuntu installation.

Yes, this is massively underdocumented and could do with some tests. Patches
welcome, as they say...

This code is supplied with NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED.
