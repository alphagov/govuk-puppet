puppet-nano
===========

nano must die

This is a very opinionated module about the installation of nano.
It can be used to actually install nano but im not going to tell you how.

```
include nano
include nano::must::die
```
do much the same thing.
