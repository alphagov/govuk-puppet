## 0.3.0 (2017-05-17)

  - Feature: use cron.d for cronjobs rather than default crontab. This allows
  us to set specific MAILTO parameters to the cron without affecting other jobs
  - Bug fix: puppet-lint errors as #{linenumber} is deprecated
  - Bug fix: puppet-lint fails on "arrow_on_right_operand_line"

## 0.2.0 (2016-02-25)
 
  - Bug fix: Ensure run-parts will execute scripts with file extensions

## 0.1.0 (2015-06-18)
 
  - Initial release
