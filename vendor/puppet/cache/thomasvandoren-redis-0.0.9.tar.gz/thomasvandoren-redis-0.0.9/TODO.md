TODO
====

* Add [logrotate module](https://github.com/ghoneycutt/puppet-logrotate) from puppet forge and rotate redis log files.
* Parameterize listening port and interface.
* Parameterize config values (ie max memory, client, etc).
